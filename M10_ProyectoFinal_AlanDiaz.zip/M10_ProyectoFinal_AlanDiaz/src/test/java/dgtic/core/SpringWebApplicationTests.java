package dgtic.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.jdbc.Sql;

@SpringBootTest
@Sql({"/schema.sql","/data.sql"})
class SpringWebApplicationTests {

	@Test
	void contextLoads() {
		System.out.println("Alan Mauricio Diaz Guerrero");
		System.out.println("Cargar esquema y datos");
	}

}
