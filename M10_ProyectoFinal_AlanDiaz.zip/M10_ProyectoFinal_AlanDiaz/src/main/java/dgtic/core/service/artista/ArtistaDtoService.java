package dgtic.core.service.artista;

import dgtic.core.dto.ArtistaDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface ArtistaDtoService {
    List<ArtistaDto> getAllArtistas();
    Optional<ArtistaDto> getArtistaById(Integer id);
    ArtistaDto createArtista(ArtistaDto artistaDto);
    ArtistaDto updateArtista(Integer id, ArtistaDto artistaDto);
    boolean deleteArtista(Integer id);
}
