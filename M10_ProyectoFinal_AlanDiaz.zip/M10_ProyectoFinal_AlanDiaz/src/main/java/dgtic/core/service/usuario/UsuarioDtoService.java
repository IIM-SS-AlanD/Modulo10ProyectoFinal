package dgtic.core.service.usuario;

import dgtic.core.dto.UsuarioDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;

public interface UsuarioDtoService {
    List<UsuarioDto> buscarAllUsuario();
    public UsuarioDto guardar(UsuarioDto usuarioDto) throws ParseException;
    public boolean borrar(Integer id);
    Optional<UsuarioDto> buscarUsuarioId(Integer id);
    public List<UsuarioDto> findUsuariosByGenero(String genero);
    public UsuarioDto updateUsuario(UsuarioDto usuarioDto) throws ParseException;
    public List<UsuarioDto> findUsuariosByCarreraProfesional(String carreraP);
}
