package dgtic.core.service.carreraProfesional;

import dgtic.core.dto.CarreraProfesionalDto;
import dgtic.core.model.entities.CarreraProfesional;
import dgtic.core.repository.CarreraProfesionalRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
@Service
public class CarreraProfesionalDtoServiceImpl implements CarreraProfesionalDtoService {

    @Autowired
    private CarreraProfesionalRepository carreraProfesionalRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<CarreraProfesionalDto> getAllCarrerasProfesionales() {
        List<CarreraProfesional> carreras = carreraProfesionalRepository.findAll();
        return carreras.stream()
                .map(carrera -> modelMapper.map(carrera, CarreraProfesionalDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public Optional<CarreraProfesionalDto> getCarreraProfesionalById(Integer id) {
        return carreraProfesionalRepository.findById(String.valueOf(id))
                .map(carrera -> modelMapper.map(carrera, CarreraProfesionalDto.class));
    }

    @Override
    public CarreraProfesionalDto createCarreraProfesional(CarreraProfesionalDto carreraProfesionalDto) {
        CarreraProfesional carrera = modelMapper.map(carreraProfesionalDto, CarreraProfesional.class);
        CarreraProfesional savedCarrera = carreraProfesionalRepository.save(carrera);
        return modelMapper.map(savedCarrera, CarreraProfesionalDto.class);
    }

    @Override
    public CarreraProfesionalDto updateCarreraProfesional(Integer id, CarreraProfesionalDto carreraProfesionalDto) {
        CarreraProfesional carrera = carreraProfesionalRepository.findById(String.valueOf(id))
                .orElseThrow(() -> new RuntimeException("Carrera Profesional no encontrada"));

        carrera.setNombre(carreraProfesionalDto.getNombre());
        CarreraProfesional updatedCarrera = carreraProfesionalRepository.save(carrera);
        return modelMapper.map(updatedCarrera, CarreraProfesionalDto.class);
    }

    @Override
    public boolean deleteCarreraProfesional(Integer id) {
        if (carreraProfesionalRepository.existsById(String.valueOf(id))) {
            carreraProfesionalRepository.deleteById(String.valueOf(id));
            return true;
        }
        return false;
    }
}