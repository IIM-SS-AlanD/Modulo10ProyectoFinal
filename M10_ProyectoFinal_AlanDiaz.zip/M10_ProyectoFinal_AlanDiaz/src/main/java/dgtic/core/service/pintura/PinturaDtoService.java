package dgtic.core.service.pintura;

import dgtic.core.dto.PinturaDto;

import java.util.List;
import java.util.Optional;

public interface PinturaDtoService {
    List<PinturaDto> getAllPinturas();
    Optional<PinturaDto> getPinturaById(Integer id);
    PinturaDto createPintura(PinturaDto pinturaDto);
    PinturaDto updatePintura(Integer id, PinturaDto pinturaDto);
    boolean deletePintura(Integer id);
}
