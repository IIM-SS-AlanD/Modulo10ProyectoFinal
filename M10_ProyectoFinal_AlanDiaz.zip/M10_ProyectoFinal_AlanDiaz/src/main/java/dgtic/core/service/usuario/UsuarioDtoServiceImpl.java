package dgtic.core.service.usuario;

import dgtic.core.controller.usuario.UsuarioDtoController;
import dgtic.core.dto.UsuarioDto;
import dgtic.core.exception.UsuarioNoEncontradoException;
import dgtic.core.model.entities.CarreraProfesional;
import dgtic.core.model.entities.Genero;
import dgtic.core.model.entities.Usuario;
import dgtic.core.repository.CarreraProfesionalRepository;
import dgtic.core.repository.GeneroRepository;
import dgtic.core.repository.UsuarioRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UsuarioDtoServiceImpl implements UsuarioDtoService{

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private GeneroRepository generoRepository;

    @Autowired
    private CarreraProfesionalRepository carreraProfesionalRepository;

    @Autowired
    private ModelMapper modelMapper;


    @Override
    public List<UsuarioDto> buscarAllUsuario() {
        List<Usuario> usuarios = usuarioRepository.findAll();
        return usuarios.stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public UsuarioDto guardar(UsuarioDto usuario) throws ParseException {
        Usuario usuarioSalvado = usuarioRepository.save(this.convertToEntity(usuario));
        return convertToDto(usuarioSalvado);
    }

    @Override
    public boolean borrar(Integer id) {
        Optional<Usuario> usuario = usuarioRepository.findById(String.valueOf(id));
        if (usuario.isPresent()){
            usuarioRepository.deleteById(String.valueOf(id));
            return true;
        }else {
            return false;
        }
    }

    @Override
    public Optional<UsuarioDto> buscarUsuarioId(Integer id) {
        Optional<Usuario> usuario=usuarioRepository.findById(String.valueOf(id));
        if (usuario.isPresent()){
            UsuarioDto usuarioDto = convertToDto(usuario.get());
            return Optional.of(usuarioDto);
        }else {
            return Optional.empty();
        }
    }

    @Override
    public List<UsuarioDto> findUsuariosByGenero(String genero) {
        List<Usuario> usuarios = usuarioRepository.findByGeneroNombre(genero);
        return usuarios.stream().map(this::convertToDto).collect(Collectors.toList());
    }

    @Override
    public UsuarioDto updateUsuario(UsuarioDto usuarioDto) throws ParseException {
        Optional<Usuario> usuarioOpt = usuarioRepository.findById(String.valueOf(usuarioDto.getId()));
        if (usuarioOpt.isPresent()) {
            Usuario usuarioActualizado = usuarioRepository.save(this.convertToEntity(usuarioDto));
            return this.convertToDto(usuarioActualizado);
        } else {
            throw new UsuarioNoEncontradoException("Usuario con ID " + usuarioDto.getId() + " no encontrado");
        }
    }

    @Override
    public List<UsuarioDto> findUsuariosByCarreraProfesional(String carreraP) {
        List<Usuario> usuarios = usuarioRepository.findByCarreraProfesionalNombre(carreraP);
        return usuarios.stream().map(this::convertToDto).collect(Collectors.toList());

    }

    private UsuarioDto convertToDto(Usuario usuario){
        UsuarioDto usuarioDto = modelMapper.map(usuario, UsuarioDto.class);
        if(usuario.getGenero() != null)
            usuarioDto.setGenero(usuario.getGenero().getNombre());
        if(usuario.getCarreraProfesional() != null)
            usuarioDto.setCarreraProfesional(usuario.getCarreraProfesional().getNombre());
        return usuarioDto;
    }

    private Usuario convertToEntity (UsuarioDto usuarioDto){
        Usuario usuario = modelMapper.map(usuarioDto, Usuario.class);
        if (usuarioDto.getGenero()!=null && !usuarioDto.getGenero().isEmpty()){
            Genero genero = generoRepository.findByNombre(usuarioDto.getGenero());
            usuario.setGenero(genero);
        }
        if (usuarioDto.getCarreraProfesional()!=null && !usuarioDto.getCarreraProfesional().isEmpty()){
            CarreraProfesional carreraProfesional = carreraProfesionalRepository.findByNombre(usuarioDto.getCarreraProfesional());
            usuario.setCarreraProfesional(carreraProfesional);
        }
        return usuario;
    }
}
