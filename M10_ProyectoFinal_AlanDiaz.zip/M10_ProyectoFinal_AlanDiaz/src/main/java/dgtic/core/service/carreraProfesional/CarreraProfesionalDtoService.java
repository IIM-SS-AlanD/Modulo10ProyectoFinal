package dgtic.core.service.carreraProfesional;

import dgtic.core.dto.CarreraProfesionalDto;

import java.util.List;
import java.util.Optional;

public interface CarreraProfesionalDtoService {
    List<CarreraProfesionalDto> getAllCarrerasProfesionales();
    Optional<CarreraProfesionalDto> getCarreraProfesionalById(Integer id);
    CarreraProfesionalDto createCarreraProfesional(CarreraProfesionalDto carreraProfesionalDto);
    CarreraProfesionalDto updateCarreraProfesional(Integer id, CarreraProfesionalDto carreraProfesionalDto);
    boolean deleteCarreraProfesional(Integer id);
}
