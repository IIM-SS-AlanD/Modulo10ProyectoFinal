package dgtic.core.service.artista;

import org.springframework.stereotype.Service;
import dgtic.core.dto.ArtistaDto;
import dgtic.core.model.entities.Artista;
import dgtic.core.repository.ArtistaRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ArtistaDtoServiceImpl implements ArtistaDtoService{

    @Autowired
    private ArtistaRepository artistaRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<ArtistaDto> getAllArtistas() {
        List<Artista> artistas = artistaRepository.findAll();
        return artistas.stream()
                .map(artista -> modelMapper.map(artista, ArtistaDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public Optional<ArtistaDto> getArtistaById(Integer id) {
        return artistaRepository.findById(String.valueOf(id))
                .map(artista -> modelMapper.map(artista, ArtistaDto.class));
    }

    @Override
    public ArtistaDto createArtista(ArtistaDto artistaDto) {
        Artista artista = modelMapper.map(artistaDto, Artista.class);
        Artista savedArtista = artistaRepository.save(artista);
        return modelMapper.map(savedArtista, ArtistaDto.class);
    }

    @Override
    public ArtistaDto updateArtista(Integer id, ArtistaDto artistaDto) {
        Artista artista = artistaRepository.findById(String.valueOf(id))
                .orElseThrow(() -> new RuntimeException("Artista no encontrado"));

        artista.setNombre(artistaDto.getNombre());
        artista.setNacionalidad(artistaDto.getNacionalidad());
        Artista updatedArtista = artistaRepository.save(artista);
        return modelMapper.map(updatedArtista, ArtistaDto.class);
    }

    @Override
    public boolean deleteArtista(Integer id) {
        if (artistaRepository.existsById(String.valueOf(id))) {
            artistaRepository.deleteById(String.valueOf(id));
            return true;
        }
        return false;
    }
}