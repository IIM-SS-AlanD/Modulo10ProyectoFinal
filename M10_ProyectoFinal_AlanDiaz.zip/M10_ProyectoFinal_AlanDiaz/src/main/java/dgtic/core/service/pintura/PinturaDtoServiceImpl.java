package dgtic.core.service.pintura;
import dgtic.core.dto.PinturaDto;
import dgtic.core.model.entities.Artista;
import dgtic.core.model.entities.Pintura;
import dgtic.core.repository.ArtistaRepository;
import dgtic.core.repository.PinturaRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PinturaDtoServiceImpl implements PinturaDtoService {

    @Autowired
    private PinturaRepository pinturaRepository;

    @Autowired
    private ArtistaRepository artistaRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<PinturaDto> getAllPinturas() {
        List<Pintura> pinturas = pinturaRepository.findAll();
        return pinturas.stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<PinturaDto> getPinturaById(Integer id) {
        return pinturaRepository.findById(id)
                .map(this::convertToDto);
    }

    @Override
    public PinturaDto createPintura(PinturaDto pinturaDto) {
        Pintura pintura = convertToEntity(pinturaDto);
        Pintura savedPintura = pinturaRepository.save(pintura);
        return convertToDto(savedPintura);
    }

    @Override
    public PinturaDto updatePintura(Integer id, PinturaDto pinturaDto) {
        Pintura pintura = pinturaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Pintura no encontrada"));

        pintura.setTituloObra(pinturaDto.getTituloObra());
        pintura.setAnioCreacion(pinturaDto.getAnioCreacion());
        pintura.setTecnica(pinturaDto.getTecnica());
        pintura.setDetalles(pinturaDto.getDetalles());

        if (pinturaDto.getIdArtista() != null) {
            Artista artista = artistaRepository.findById(String.valueOf(pinturaDto.getIdArtista()))
                    .orElseThrow(() -> new RuntimeException("Artista no encontrado"));
            pintura.setArtista(artista);
        }

        Pintura updatedPintura = pinturaRepository.save(pintura);
        return convertToDto(updatedPintura);
    }

    @Override
    public boolean deletePintura(Integer id) {
        if (pinturaRepository.existsById(id)) {
            pinturaRepository.deleteById(id);
            return true;
        }
        return false;
    }

    // Métodos auxiliares
    private PinturaDto convertToDto(Pintura pintura) {
        PinturaDto pinturaDto = modelMapper.map(pintura, PinturaDto.class);
        if (pintura.getArtista() != null) {
            pinturaDto.setIdArtista(pintura.getArtista().getId());
            pinturaDto.setNombreArtista(pintura.getArtista().getNombre());
        }
        return pinturaDto;
    }

    private Pintura convertToEntity(PinturaDto pinturaDto) {
        Pintura pintura = modelMapper.map(pinturaDto, Pintura.class);
        if (pinturaDto.getIdArtista() != null) {
            Artista artista = artistaRepository.findById(String.valueOf(pinturaDto.getIdArtista()))
                    .orElseThrow(() -> new RuntimeException("Artista no encontrado"));
            pintura.setArtista(artista);
        }
        return pintura;
    }
}