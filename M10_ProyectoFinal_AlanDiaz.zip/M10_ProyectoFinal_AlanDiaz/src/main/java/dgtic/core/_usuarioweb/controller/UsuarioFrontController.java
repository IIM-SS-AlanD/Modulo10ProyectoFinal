package dgtic.core._usuarioweb.controller;

import dgtic.core._usuarioweb.services.UsuarioFrontServices;
import dgtic.core._usuarioweb.services.UsuarioWebClientServices;
import dgtic.core.dto.UsuarioDto;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class UsuarioFrontController {

    @Autowired
    private UsuarioFrontServices service;
    @Autowired
    private UsuarioWebClientServices usuarioWebClientServices;

    @GetMapping(path = "/front/usuarios/{id}")
    public String getUsuario(@PathVariable Integer id, Model model) {
        UsuarioDto usuarioDto = service.getUsuarioById(id);
        model.addAttribute("usuario", usuarioDto);
        return "usuariodetalle";
    }

    @GetMapping(path = "/front/usuarios/")
    public String getAllUsuarios(Model model) {
        model.addAttribute("usuarios", usuarioWebClientServices.getAll());
        return "usuarios";
    }

    @GetMapping(path = "/front/usuarios/{id}/editar")
    public String getFormEditar(@PathVariable Integer id, Model model){
        UsuarioDto usuarioDto = usuarioWebClientServices.getUsuarioById(id);

        model.addAttribute("usuario",usuarioDto);
        return "formEditar";
    }

    @PutMapping(path = "/front/usuarios/editar")
    public String actualizarUsuario(@Valid @RequestBody UsuarioDto usuarioDto, Model model){
        UsuarioDto actualizaUsuario = usuarioWebClientServices.actualizaUsuario(usuarioDto);
        model.addAttribute("usuario",actualizaUsuario);
        return "formEditar";
    }

    @GetMapping(path = "/front/usuarios/nuevo")
    public String getFormNuevoUsuario(Model model) {
        model.addAttribute("usuario", new UsuarioDto());
        return "formNuevoUsuario";
    }

    @PostMapping(path = "/front/usuarios/nuevo")
    public String crearNuevoUsuario(@Valid @ModelAttribute("usuario") UsuarioDto usuarioDto, Model model) {
        UsuarioDto nuevoUsuario = usuarioWebClientServices.crearUsuario(usuarioDto);
        return "redirect:/front/usuarios/" + nuevoUsuario.getId();
    }

    @GetMapping("/principal")
    public String principal() {
        return "principal";
    }

    @GetMapping("/galeria")
    public String mostrarGaleria(Model model) {
        // Añade lógica si es necesario
        return "galeria";
    }
}
