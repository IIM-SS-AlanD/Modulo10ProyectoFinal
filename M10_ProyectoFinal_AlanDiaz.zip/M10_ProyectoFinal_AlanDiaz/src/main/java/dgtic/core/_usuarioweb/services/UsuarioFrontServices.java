package dgtic.core._usuarioweb.services;

import dgtic.core.dto.UsuarioDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class UsuarioFrontServices {
    public static final String API_URL = "http://localhost:8080/api/usuarios";

    @Autowired
    private RestTemplate restTemplate;

    public UsuarioDto getUsuarioById(Integer id) {
        String url = API_URL + "/" + id;
        return restTemplate.getForObject(url, UsuarioDto.class);
    }
}
