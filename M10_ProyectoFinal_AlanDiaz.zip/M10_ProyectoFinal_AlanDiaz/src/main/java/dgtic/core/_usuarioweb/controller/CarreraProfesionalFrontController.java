package dgtic.core._usuarioweb.controller;

import dgtic.core.dto.CarreraProfesionalDto;
import dgtic.core.service.carreraProfesional.CarreraProfesionalDtoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/carrerasprofesionales")
public class CarreraProfesionalFrontController {

    @Autowired
    private CarreraProfesionalDtoService carreraProfesionalService;

    @GetMapping("/")
    public List<CarreraProfesionalDto> getAllCarrerasProfesionales() {
        return carreraProfesionalService.getAllCarrerasProfesionales();
    }

    @GetMapping("/{id}")
    public ResponseEntity<CarreraProfesionalDto> getCarreraProfesionalById(@PathVariable Integer id) {
        Optional<CarreraProfesionalDto> carrera = carreraProfesionalService.getCarreraProfesionalById(id);
        return carrera.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/")
    public ResponseEntity<CarreraProfesionalDto> createCarreraProfesional(@RequestBody CarreraProfesionalDto carreraProfesionalDto) {
        CarreraProfesionalDto nuevaCarrera = carreraProfesionalService.createCarreraProfesional(carreraProfesionalDto);
        URI location = URI.create("/api/carrerasprofesionales/" + nuevaCarrera.getId());
        return ResponseEntity.created(location).body(nuevaCarrera);
    }

    @PutMapping("/{id}")
    public ResponseEntity<CarreraProfesionalDto> updateCarreraProfesional(@PathVariable Integer id, @RequestBody CarreraProfesionalDto carreraProfesionalDto) {
        CarreraProfesionalDto carreraActualizada = carreraProfesionalService.updateCarreraProfesional(id, carreraProfesionalDto);
        return ResponseEntity.ok(carreraActualizada);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCarreraProfesional(@PathVariable Integer id) {
        if (carreraProfesionalService.deleteCarreraProfesional(id)) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

}
