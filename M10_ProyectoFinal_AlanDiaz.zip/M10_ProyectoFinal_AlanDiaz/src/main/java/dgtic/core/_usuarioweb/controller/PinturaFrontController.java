package dgtic.core._usuarioweb.controller;

import dgtic.core.dto.PinturaDto;
import dgtic.core.service.pintura.PinturaDtoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/pinturas")
public class PinturaFrontController {

    @Autowired
    private PinturaDtoService pinturaService;

    @GetMapping("/")
    public List<PinturaDto> getAllPinturas() {
        return pinturaService.getAllPinturas();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PinturaDto> getPinturaById(@PathVariable Integer id) {
        Optional<PinturaDto> pintura = pinturaService.getPinturaById(id);
        return pintura.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/")
    public ResponseEntity<PinturaDto> createPintura(@RequestBody PinturaDto pinturaDto) {
        PinturaDto nuevaPintura = pinturaService.createPintura(pinturaDto);
        URI location = URI.create("/api/pinturas/" + nuevaPintura.getId());
        return ResponseEntity.created(location).body(nuevaPintura);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PinturaDto> updatePintura(@PathVariable Integer id, @RequestBody PinturaDto pinturaDto) {
        PinturaDto pinturaActualizada = pinturaService.updatePintura(id, pinturaDto);
        return ResponseEntity.ok(pinturaActualizada);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePintura(@PathVariable Integer id) {
        if (pinturaService.deletePintura(id)) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}
