package dgtic.core._usuarioweb.services;

import dgtic.core.dto.UsuarioDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class UsuarioWebClientServices {
    @Autowired
    private WebClient webClient;

    public List<UsuarioDto> getAll() {
        Mono<List<UsuarioDto>> usuariosMono = webClient.get()
                .uri("/")
                .retrieve()
                .bodyToFlux(UsuarioDto.class)
                .collectList();

        List<UsuarioDto> usuarios = usuariosMono.block();
        return usuarios;
    }

    public UsuarioDto getUsuarioById(Integer id) {
        Mono<UsuarioDto> usuarioDtoMono = webClient.get()
                .uri("/{id}",id)
                .retrieve()
                .bodyToMono(UsuarioDto.class);
        UsuarioDto usuarioDto = usuarioDtoMono.block();
        return usuarioDto;
    }

    public UsuarioDto actualizaUsuario(UsuarioDto usuarioDto){
        return webClient.put()
                .uri("/{id}",usuarioDto.getId())
                .bodyValue(usuarioDto)
                .retrieve()
                .bodyToMono(UsuarioDto.class)
                .block();
    }

    public UsuarioDto crearUsuario(UsuarioDto usuarioDto) {
        return webClient.post()
                .uri("/")
                .bodyValue(usuarioDto)
                .retrieve()
                .bodyToMono(UsuarioDto.class)
                .block();
    }

}
