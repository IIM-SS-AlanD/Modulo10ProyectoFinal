package dgtic.core._usuarioweb.controller;

import dgtic.core.dto.ArtistaDto;
import dgtic.core.service.artista.ArtistaDtoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/artistas")
public class ArtistaFrontController {

    @Autowired
    private ArtistaDtoService artistaService;

    @GetMapping("/")
    public List<ArtistaDto> getAllArtistas() {
        return artistaService.getAllArtistas();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ArtistaDto> getArtistaById(@PathVariable Integer id) {
        Optional<ArtistaDto> artista = artistaService.getArtistaById(id);
        return artista.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/")
    public ResponseEntity<ArtistaDto> createArtista(@RequestBody ArtistaDto artistaDto) {
        ArtistaDto nuevoArtista = artistaService.createArtista(artistaDto);
        URI location = URI.create("/api/artistas/" + nuevoArtista.getId());
        return ResponseEntity.created(location).body(nuevoArtista);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ArtistaDto> updateArtista(@PathVariable Integer id, @RequestBody ArtistaDto artistaDto) {
        ArtistaDto artistaActualizado = artistaService.updateArtista(id, artistaDto);
        return ResponseEntity.ok(artistaActualizado);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteArtista(@PathVariable Integer id) {
        if (artistaService.deleteArtista(id)) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
}
