package dgtic.core.exception;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class ManejadorGlobalExcepciones {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<DetalleError> manejoErroresValidacion(MethodArgumentNotValidException ex) {
        DetalleError detalleError = new DetalleError();
        detalleError.setMensaje("Error de validación de campos");
        detalleError.setStatusCode(HttpStatus.BAD_REQUEST.toString());
        detalleError.setTimeStamp(LocalDateTime.now());

        Map<String, String> errores = new HashMap<>();
        for (FieldError error : ex.getBindingResult().getFieldErrors()) {
            errores.put(error.getField(), error.getDefaultMessage());
        }
        detalleError.setDetalle(errores.toString());

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(detalleError);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<DetalleError> manejoErrorFormato(HttpMessageNotReadableException ex) {
        DetalleError detalleError = new DetalleError();
        detalleError.setMensaje("El formato de los datos es incorrecto");
        detalleError.setStatusCode(HttpStatus.BAD_REQUEST.toString());
        detalleError.setTimeStamp(LocalDateTime.now());
        detalleError.setDetalle(ex.getMessage());

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(detalleError);
    }

    @ExceptionHandler(UsuarioNoEncontradoException.class)
    public ResponseEntity<DetalleError> manejoUsuarioNoEncontrado(UsuarioNoEncontradoException ex) {
        DetalleError detalleError = new DetalleError();
        detalleError.setMensaje(ex.getMessage());
        detalleError.setStatusCode(HttpStatus.NOT_FOUND.toString());
        detalleError.setTimeStamp(LocalDateTime.now());
        detalleError.setDetalle("El usuario solicitado no existe");

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(detalleError);
    }
}
