package dgtic.core.model.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "tarjetas")
@NamedQuery(name = "Tarjeta.findBySaldoGreaterThan", query = "SELECT t FROM Tarjeta t WHERE t.saldo > :saldo")

public class Tarjeta {
    @Id
    private Integer id;
    private String nombreTitular;
    private String apellidoTitular;
    private String numeroTarjeta;
    private String fechaExpiracion;
    private String tipoTarjeta;
    private Float saldo;

    @ManyToOne
    @JoinColumn(name = "idUsuario")
    private Usuario usuario;


}
