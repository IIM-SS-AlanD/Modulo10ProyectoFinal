package dgtic.core.dto;

import java.time.LocalDate;
import java.util.Objects;

public class PinturaDto {
    private Integer id;
    private String tituloObra;
    private LocalDate anioCreacion;
    private String tecnica;
    private String detalles;
    private Integer idArtista; // Referencia al ID del Artista
    private String nombreArtista; // Nombre del Artista (opcional)

    public PinturaDto() {
    }

    public PinturaDto(Integer id, String tituloObra, LocalDate anioCreacion, String tecnica, String detalles, Integer idArtista, String nombreArtista) {
        this.id = id;
        this.tituloObra = tituloObra;
        this.anioCreacion = anioCreacion;
        this.tecnica = tecnica;
        this.detalles = detalles;
        this.idArtista = idArtista;
        this.nombreArtista = nombreArtista;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTituloObra() {
        return tituloObra;
    }

    public void setTituloObra(String tituloObra) {
        this.tituloObra = tituloObra;
    }

    public LocalDate getAnioCreacion() {
        return anioCreacion;
    }

    public void setAnioCreacion(LocalDate anioCreacion) {
        this.anioCreacion = anioCreacion;
    }

    public String getTecnica() {
        return tecnica;
    }

    public void setTecnica(String tecnica) {
        this.tecnica = tecnica;
    }

    public String getDetalles() {
        return detalles;
    }

    public void setDetalles(String detalles) {
        this.detalles = detalles;
    }

    public Integer getIdArtista() {
        return idArtista;
    }

    public void setIdArtista(Integer idArtista) {
        this.idArtista = idArtista;
    }

    public String getNombreArtista() {
        return nombreArtista;
    }

    public void setNombreArtista(String nombreArtista) {
        this.nombreArtista = nombreArtista;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PinturaDto that = (PinturaDto) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "PinturaDto{" +
                "id=" + id +
                ", tituloObra='" + tituloObra + '\'' +
                ", anioCreacion=" + anioCreacion +
                ", tecnica='" + tecnica + '\'' +
                ", detalles='" + detalles + '\'' +
                ", idArtista=" + idArtista +
                ", nombreArtista='" + nombreArtista + '\'' +
                '}';
    }
}
