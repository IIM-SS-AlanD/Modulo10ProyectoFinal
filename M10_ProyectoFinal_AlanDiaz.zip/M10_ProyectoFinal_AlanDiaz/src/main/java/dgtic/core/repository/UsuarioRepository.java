package dgtic.core.repository;

import dgtic.core.model.entities.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface UsuarioRepository extends JpaRepository<Usuario,String> {
    boolean existsByCorreo(String email);


    List<Usuario> findByCarreraProfesionalNombre(String nombre);
    List<Usuario> findByGeneroNombre(String nombre);
}
