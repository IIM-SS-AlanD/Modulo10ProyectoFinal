package dgtic.core.repository;

import dgtic.core.model.entities.Producto;
import dgtic.core.model.entities.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoRepository extends JpaRepository<Producto,String> {
}
