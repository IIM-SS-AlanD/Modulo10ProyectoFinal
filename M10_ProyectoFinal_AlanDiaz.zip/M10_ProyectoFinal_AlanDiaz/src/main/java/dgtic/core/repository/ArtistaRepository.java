package dgtic.core.repository;

import dgtic.core.model.entities.Artista;
import dgtic.core.model.entities.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ArtistaRepository extends JpaRepository<Artista,String> {
}
