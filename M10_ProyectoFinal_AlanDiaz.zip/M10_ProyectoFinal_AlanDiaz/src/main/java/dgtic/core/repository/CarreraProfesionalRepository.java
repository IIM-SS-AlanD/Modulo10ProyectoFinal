package dgtic.core.repository;

import dgtic.core.model.entities.CarreraProfesional;
import dgtic.core.model.entities.Genero;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarreraProfesionalRepository extends JpaRepository<CarreraProfesional,String> {


    CarreraProfesional findByNombre(String carreraProfesional);


}
