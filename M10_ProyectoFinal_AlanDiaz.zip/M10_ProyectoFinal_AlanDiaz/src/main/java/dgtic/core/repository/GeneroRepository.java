package dgtic.core.repository;

import dgtic.core.model.entities.Genero;
import dgtic.core.model.entities.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GeneroRepository extends JpaRepository<Genero,String> {

    Genero findByNombre(String genero);


}
