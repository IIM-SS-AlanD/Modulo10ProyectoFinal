package dgtic.core.repository;

import dgtic.core.model.entities.Pintura;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PinturaRepository extends JpaRepository<Pintura,Integer> {
}
