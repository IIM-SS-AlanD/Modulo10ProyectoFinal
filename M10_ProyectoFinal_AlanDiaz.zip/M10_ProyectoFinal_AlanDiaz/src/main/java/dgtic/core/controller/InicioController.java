package dgtic.core.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Controller
public class InicioController {
    @Value("${spring.application.name}")
    String nombreApp;

    @GetMapping("/")
    public String inicioPagina(Model model){
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        model.addAttribute("nombreAplicacion",nombreApp);
        model.addAttribute("fecha",formato.format(new Date()));
        return "inicio";
    }

    @GetMapping("/inicio")
    public String inicioPrincipal(Model model){
        model.addAttribute("contenido","Bienvenido");
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        model.addAttribute("fecha",formato.format(new Date()));
        model.addAttribute("nombreAplicacion","Seleccione alguna de las opciones para ver las listas o dar de alta.");
        List<String> pinturas = Arrays.asList("imagen/Diego-Velazquez-Waterseller-of-Seville.jpg", "imagen/pedro-pablo-rubens-immaculate-conception-1628-1629-flemish-school-pieter-paul-rubens--peter-paul-rubens-1577-1640.jpg", "imagen/Peter_Paul_Rubens_-_The_miracles_of_St._Francis_Xavier_-_Google_Art_Project.jpg");
        model.addAttribute("pinturas", pinturas);
        return "principal";
    }

    @GetMapping("/pinturas")
    public String mostrarPinturas(Model model) {
        List<String> pinturas = Arrays.asList("C:/imagenes/Diego-Velazquez-Waterseller-of-Seville.jpg", "C:/imagenes/pedro-pablo-rubens-immaculate-conception-1628-1629-flemish-school-pieter-paul-rubens--peter-paul-rubens-1577-1640.jpg", "C:/imagenes/Peter_Paul_Rubens_-_The_miracles_of_St._Francis_Xavier_-_Google_Art_Project.jpg");
        model.addAttribute("pinturas", pinturas);
        return "tuVista";
    }
}