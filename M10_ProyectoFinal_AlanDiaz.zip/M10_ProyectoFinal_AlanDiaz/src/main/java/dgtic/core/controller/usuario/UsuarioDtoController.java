package dgtic.core.controller.usuario;


import dgtic.core.dto.UsuarioDto;
import dgtic.core.service.usuario.UsuarioDtoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(path = "/api/usuarios")
public class UsuarioDtoController {

    @Autowired
    UsuarioDtoService usuarioDtoService;

    //obtener todos
    @GetMapping(path = "/")
    public List<UsuarioDto> getAllDto(){
        return usuarioDtoService.buscarAllUsuario();
    }

    //obtener por Id
    @GetMapping(path = "/{id}")
    public ResponseEntity<UsuarioDto> buscarUsuarioId(@PathVariable Integer id){
        Optional<UsuarioDto> usuarioDto =usuarioDtoService.buscarUsuarioId(id);
        if (usuarioDto.isPresent()){
            return ResponseEntity.ok(usuarioDto.get());
        }else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping(path = "/")
    public ResponseEntity<UsuarioDto> guardarUsuarioDto(@RequestBody UsuarioDto usuarioDto) throws ParseException, URISyntaxException {
        UsuarioDto usuarioDto1 = usuarioDtoService.guardar(usuarioDto);
        URI location = new URI("/api/usuarios/"+ usuarioDto1.getId());
        return ResponseEntity.created(location).body(usuarioDto1);
    }

    @PutMapping(path = "/{id}")
    public ResponseEntity<UsuarioDto> modificarUsuario (@PathVariable Integer id, @RequestBody UsuarioDto usuarioDto) throws ParseException{
        usuarioDto.setId(id);
        UsuarioDto usuarioDto1 = usuarioDtoService.updateUsuario(usuarioDto);
        return ResponseEntity.ok(usuarioDto1);
    }

    @PatchMapping(path = "/{id}")
    public ResponseEntity<UsuarioDto> actualizacionParcialUsuario (
            @PathVariable Integer id,
            @RequestBody UsuarioDto usuarioDto
    ) throws ParseException{
        Optional<UsuarioDto> usuarioDb = usuarioDtoService.buscarUsuarioId(id);
        if(usuarioDb.isPresent()){
            UsuarioDto modificable = usuarioDb.get();
            if (usuarioDto.getNombre() != null) modificable.setNombre(usuarioDto.getNombre());
            if (usuarioDto.getCorreo() != null) modificable.setCorreo(usuarioDto.getCorreo());
            if (usuarioDto.getDireccion() != null) modificable.setDireccion(usuarioDto.getDireccion());
            if (usuarioDto.getTelefono() != null) modificable.setTelefono(usuarioDto.getTelefono());
            if (usuarioDto.getContrasena() != null) modificable.setContrasena(usuarioDto.getContrasena());
            if (usuarioDto.getGenero() != null) modificable.setGenero(usuarioDto.getGenero());
            if (usuarioDto.getCarreraProfesional() != null) modificable.setCarreraProfesional(usuarioDto.getCarreraProfesional());
            return ResponseEntity.ok(usuarioDtoService.updateUsuario(modificable));
        }else {
            return ResponseEntity.notFound().build();
        }

    }

    @DeleteMapping(path = "/{id}")
    public ResponseEntity<?> eliminarAlumno (
            @PathVariable Integer id
    ){
        if (usuarioDtoService.borrar(id)){
            return ResponseEntity.ok().build();
        }else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping(path = "/genero/{genero}")
    public ResponseEntity<List<UsuarioDto>> getByGenero(@PathVariable String genero) {
        return ResponseEntity.ok(usuarioDtoService.findUsuariosByGenero(genero));
    }

    @GetMapping(path = "/carreraP/{carreraProfesional}")
    public ResponseEntity<List<UsuarioDto>> getByCarreraProfesional(@PathVariable String carreraProfesional) {
        return ResponseEntity.ok(usuarioDtoService.findUsuariosByCarreraProfesional(carreraProfesional));
    }
}

