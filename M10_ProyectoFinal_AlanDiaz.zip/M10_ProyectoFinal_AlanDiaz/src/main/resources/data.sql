
INSERT INTO artista (nombre, nacionalidad) VALUES
('Vincent van Gogh', 'Holandesa'),
('Leonardo da Vinci', 'Italiana'),
('Claude Monet','Frances'),
('Diego Velázquez','Español'),
('Joan Miró','Frances'),
('El Greco','España'),
('Raphael','Italiano');

INSERT INTO pinturas (tituloObra, idArtista, anioCreacion, tecnica, detalles) VALUES
('Starry Night', 2, '1889-06-01', 'Óleo sobre lienzo', 'Una de las obras más famosas de Van Gogh, representa una vista desde su habitación en el asilo de Saint-Rémy-de-Provence.'),
('La Última Cena', 1, '1498-01-01', 'Tempera y óleo sobre yeso', 'Representa la última cena de Jesús con sus apóstoles antes de su crucifixión.'),
('El Grito', 1, '1893-01-01', 'Óleo, temple y pastel sobre cartón', 'Una de las imágenes más icónicas del arte moderno, simboliza la ansiedad del hombre moderno.'),
('Impresión, sol naciente', 3, '1872-04-01', 'Óleo sobre lienzo', 'La obra que dio nombre al movimiento impresionista, muestra el puerto de Le Havre al amanecer.'),
('Las Meninas', 4, '1656-01-01', 'Óleo sobre lienzo', 'Una de las obras más analizadas del arte occidental, representa a la infanta Margarita Teresa rodeada de su corte.'),
('El Carnaval del Arlequín', 5, '1924-01-01', 'Óleo sobre lienzo', 'Una obra surrealista llena de formas abstractas y simbólicas que reflejan el mundo onírico de Miró.'),
('El Entierro del Conde de Orgaz', 6, '1586-01-01', 'Óleo sobre lienzo', 'Una obra maestra que combina el naturalismo renacentista con el misticismo bizantino, representando un milagro ocurrido en Toledo.'),
('La Escuela de Atenas', 7, '1511-01-01', 'Fresco', 'Un fresco que representa a los grandes filósofos de la antigüedad, es una obra clave del Renacimiento italiano.');

INSERT INTO genero (nombre) VALUES
('Impresionismo'),
('Renacimiento');

INSERT INTO carreraProfesional (nombre) VALUES
('Ingeniería'),
('Arquitectura'),
('Diseño Gráfico');

INSERT INTO productos (clave_producto, nombre, precio, descripcion, stock) VALUES
('TZA-VG-001', 'Taza de Starry Night',114.99, 'Taza de cerámica con la obra Starry Night de Vincent van Gogh', 100),
('GOR-VG-001', 'Gorra de La Noche Estrellada', 319.99, 'Gorra de algodón con diseño inspirado en La Noche Estrellada', 50),
('LEG-DV-001', 'Set de Lego La Última Cena', 299.99, 'Set de Lego para recrear la famosa pintura La Última Cena', 20),
('POS-DV-001', 'Póster de La Mona Lisa', 212.99, 'Póster de alta calidad de La Mona Lisa', 200),
('CAM-MU-001', 'Camiseta El Grito', 225.00, 'Camiseta de algodón con impresión de El Grito', 75);

INSERT INTO usuarios (id, correo, nombre, contrasena,idGenero, id_carrera_profesional, direccion, telefono) VALUES
(1, 'juan.perez@example.com', 'Juan', 'hashed_password_1', 1, 3,'Calle Falsa 123, Ciudad', '555-1234'),
(2, 'maria.lopez@example.com', 'María', 'hashed_password_2', 1, 2,'Avenida Siempreviva 742, Ciudad', '555-5678'),
(3, 'carlos.garcia@example.com', 'Carlos', 'hashed_password_3', 2, 1, 'Boulevard de los Sueños Rotos, Ciudad', '555-9012');

INSERT INTO ventas (id,idUsuario, total, fecha) VALUES
(5,1, 114.99, '2023-10-12 16:00:00'),
(6,3, 225.00, '2023-10-13 13:20:00');

INSERT INTO tarjetas (idUsuario, nombreTitular, apellidoTitular, numeroTarjeta, fechaExpiracion, tipoTarjeta, saldo) VALUES
(1, 'Juan', 'Pérez', '1234-5678-9012-3456', '12/24', 'Visa', 5000.00),
(2, 'María', 'López', '2345-6789-0123-4567', '11/23', 'MasterCard', 3000.50),
(2, 'Carlos', 'García', '3456-7890-1234-5678', '10/25', 'Amex', 1200.75);

INSERT INTO carritoProducto (idVentas, claveProducto, cantidad) VALUES
(5, 'TZA-VG-001', 2),
(6, 'GOR-VG-001', 1);

INSERT INTO pinturaEstudiada (idPintura, idUsuario, fechaEstudio, observaciones) VALUES
(1, 1, '2023-09-01 10:00:00', 'Estudio sobre técnicas de pinceladas'),
(2, 2, '2023-09-02 11:30:00', 'Análisis de la composición');
